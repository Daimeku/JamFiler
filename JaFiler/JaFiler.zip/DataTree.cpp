#include "stdafx.h"
#include "DataTree.h"


DataTree::DataTree(void)
{
	root=NULL;
}


DataTree::~DataTree(void)
{
}

DataTree::DataTree(FObject *r)
{
	root= r;

}

void DataTree::setRoot(FObject *r)
{
	root=r;
}

FObject* DataTree::getRoot()
{
	return root;
}


void DataTree::insertFile(FObject *r,FObject *f)
						  
{


	if(r==NULL)
	{
		setRoot(f);
		//r=f;
	}
	else{

		if(f->getFileNum() <= r->getFileNum())
		{
			if(r->getLeft()==NULL) 
				r->setLeft(f);
			else
				insertFile(r->getLeft(),f);
		}
		else
		{
			if(r->getRight()==NULL)
				r->setRight(f);
			else
				insertFile(r->getRight(),f);
		}
}
}


	void DataTree::FillTree(void)	// to populate the tree based on the txt file
	{
		ifstream inp("FStore.txt",ios::in);		
	
	
	string n;
	int fn, md[3],cd[3],ld[3],lwd[3];

	while(!inp.eof())		// while not at the end of the file, populate the temp object
	{
		FObject *temp= new FObject();
	inp>>fn>>n;
	inp>>md[0]>>md[1]>>md[2];
	inp>>cd[0]>>cd[1]>>cd[2];
	inp>>ld[0]>>ld[1]>>ld[2];
	inp>>lwd[0]>>lwd[1]>>lwd[2];

	cout<<"Info read"<<endl;

	temp->setFileNum(fn);
	temp->setName(n);
	temp->setMD(md[0],md[1],md[2]);
	temp->setCD(cd[0],cd[1],cd[2]);
	temp->setLD(ld[0],ld[1],ld[2]);
	temp->setLWD(lwd[0],lwd[1],lwd[2]);

	cout<<"OBject stored"<<endl;
	//temp->display();
	insertFile(root,temp);	// add the node to the binary tree
	cout<<"File inserted"<<endl;

	cout<<"**************************"<<endl;
	cout<<"Test data"<<endl;
	cout<<"fnum: "<<fn<<"name: "<<n<<endl;
	cout<<"****************************"<<endl;
	system("pause");

	}

}

	void DataTree::inOrder(FObject *f)
	{
		if(f!=NULL)
		{
			inOrder(f->getLeft());
			f->display();
			inOrder(f->getRight());
		}

	}


	bool DataTree::deleteFile(FObject *r,int fn)
	{


		FObject *curr = new FObject();
		FObject *par = new FObject();
		bool found= false;

		curr=r;

		while(curr!=NULL){    // while the current file isnt null



			if(curr->getFileNum() !=fn)		// if the current filenum doesnt match the one being searched for
			{
				if(fn <= curr->getFileNum())	// if the filenum  being searched for is less than the current one
				{
					par=curr;					// parfent becomes the current file and 
					curr=curr->getLeft();
				}
				else     // if the filenum being searched for is greater than the current one
				{
					par=curr;
					curr=curr->getRight();
				}

			}
			else // if the current filenum actually matches the one being searched for
			{
				found=true;
				break;	// break from the while loop
			}

			
		}
		
		
		if(found==false)			// if the file isnt found
		{
			cout<<"File not Found"<<endl;
			return false;

		}
		
		if(curr->getLeft() != NULL && curr->getRight()==NULL)	// if there is a left child and no right child
		{
			if(par->getRight() == curr)
				par->setRight(curr->getLeft());
			else
				par->setLeft(curr->getLeft());

			delete curr;

		}

		if(curr->getRight() != NULL && curr->getLeft() == NULL)	// if there is a right and no left child
		{
			if(par->getRight()==curr)
				par->setRight(curr->getRight());
			else
				par->setLeft(curr->getRight());

			delete curr;

		}

		if(curr->getLeft() !=NULL && curr->getRight() != NULL) // if there is a left and right child
		{
			FObject *tmp = new FObject;
			tmp= curr->getRight();

			if(tmp->getLeft() != NULL)
			{
				insertFile(tmp, curr->getLeft());

			}
			else
			{
				tmp->setLeft(curr->getLeft());

			}

			curr=tmp;
			delete tmp;
		}
		return true;

		}