// JaFiler.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "FObject.h"
#include "DataTree.h"



 
void addFile(void);
void viewFiles(void);



int _tmain(int argc, _TCHAR* argv[])
{
	system("color 0a");
	ifstream amount("Record.txt", ios::in);	// reading record file
	DataTree *sys = new DataTree();
	
	
															//testing if tree is filled
	sys->FillTree();
	/*
	cout<<"Tree filled"<<endl;
	sys->inOrder(sys->getRoot());
	cout<<"***********************"<<endl;
	cout<<"End of test"<<endl;
		system("pause");
	*/
	
	char cont='1';
	while (cont=='1')
	{
		system("cls");
		char i;
		bool f;
		int fn;

		cout<<"*********"<<endl;
		cout<<"main menu"<<endl;
		cout<<"*********"<<endl<<endl;

		cout<<"1...........add file"<<endl;
		cout<<"2...........View files"<<endl;
		cout<<"3...........Modify Files"<<endl;
		cout<<"4...........Delete Files"<<endl;
		cout<<"5...........exit"<<endl;


	
		i=cin.get();

		switch(i)
		{
		case '1': addFile();
				break;
		case '2':cout<<"\t\tFile name->filenum->last modified->created->accessed->written to"<<endl;
			//viewFiles();
			sys->inOrder(sys->getRoot());
			system("pause");
				break;
		case '3':	cout<<"****************"<<endl;
					cout<<"Modify File"<<endl;
					cout<<"****************"<<endl;
				break;
		case '4':	cout<<"****************"<<endl;
					cout<<"Delete file "<<endl;
					cout<<"****************"<<endl;
					cout<<"Enter filenum: ";
					cin>>fn;
					f=sys->deleteFile(sys->getRoot(),fn);
				break;
		case '5': cont='5';
					break; 
		default: cout<<"incorrect input"<<endl;
				break;
		}
	}



	system("pause");
	return 0;
}

void addFile()
{
	
	FObject temp;
	int d,m, y;
	string n;
	srand(time (NULL));
int fn = rand()%   RAND_MAX +1000;
	

temp.setFileNum(fn);


	cout<<fn<<endl;
	cout<<"Enter File name: ";			// getting file name
	cin>>n;
	temp.setName(n);

	cout<<"****DATE LAST MODIFIED*****"<<endl;
	cout<<"***************************"<<endl;
	temp.ddate(1); // to get date modified
	cout<<"****Date Created***********"<<endl;
	cout<<"***************************"<<endl;
	temp.ddate(2);
	cout<<"****DATE LAST ACCESSED*****"<<endl;
	cout<<"***************************"<<endl;
	temp.ddate(3);
	cout<<"****DATE LAST WRITTEN TO***"<<endl;
	cout<<"***************************"<<endl;
	temp.ddate(4);
	cout<<"out";


	temp.toFile();// adding information to file
	
	
}




void viewFiles()
{
	ifstream inp("FStore.txt",ios::in);
	
	
	string n;
	int fn, md[3],cd[3],ld[3],lwd[3];

	while(!inp.eof())
	{
		FObject *temp= new FObject();
	inp>>fn>>n;
	inp>>md[0]>>md[1]>>md[2];
	inp>>cd[0]>>cd[1]>>cd[2];
	inp>>ld[0]>>ld[1]>>ld[2];
	inp>>lwd[0]>>lwd[1]>>lwd[2];

	temp->setFileNum(fn);
	temp->setName(n);
	temp->setMD(md[0],md[1],md[2]);
	temp->setCD(cd[0],cd[1],cd[2]);
	temp->setLD(ld[0],ld[1],ld[2]);
	temp->setLWD(lwd[0],lwd[1],lwd[2]);

	temp->display();
	

	}
	
	system("pause");

	
	


}